<!doctype html>
<html>
    <head>
        <title>Home</title>
    </head>

    <body>
        <header>
            <h1>Home</h1>
        </header>
    </body>
</html>