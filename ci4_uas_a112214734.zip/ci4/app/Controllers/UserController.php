<?php

		namespace App\Controllers;
		use App\Models\UserModel;

		class UserController extends BaseController
		{
			protected $member;

			function __construct()
			{
				helper('form');
				$this->validation = \Config\Services::validation();
				$this->member = new UserModel();
			}

			public function index()
			{
				$data['members'] = $this->member->findAll();
				return view('v_member', $data);
			}

			

			public function edit($id)
			{
				$data = $this->request->getPost();
				$validate = $this->validation->run($data, 'member');
				$errors = $this->validation->getErrors();

				if(!$errors){
					$dataForm = [
						// 'username' => $this->request->getPost('username'),
						'role' => $this->request->getPost('role'),
						'is_aktif' => $this->request->getPost('is_aktif'),
					];

                    // if($this->request->getPost('is_aktif')){
					// 	$dataForm['is_aktif'] = "1";
						             
					// }

					$this->member->update($id, $dataForm);

					return redirect('member')->with('success','Data Berhasil Diubah');
				}else{
					return redirect('member')->with('failed',implode("",$errors));
				}
				
			}

			public function delete($id)
			{
				$dataMember = $this->member->find($id);

				$this->member->delete($id);

				return redirect('member')->with('success','Data Berhasil Dihapus');
			}

			public function create()
			{
				$registrar = $this->request->getPost();
				$validate = $this->validation->run($registrar, 'user');
				$errors = $this->validation->getErrors();

				if(!$errors) {
					$registrarForm = [ 
						'username' => $this->request->getPost('uname'),
						'password' => md5($this->request->getPost('passw')),
						'role'	   => "user",
					];					
			
					$this->member->insert($registrarForm); 

					return redirect('member')->with('success','Akun berhasil Dibuat');
				}else{
					return redirect('member')->with('failed',implode("",$errors));
				}
			}
		}